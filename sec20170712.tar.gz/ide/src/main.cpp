#include "qtquickcontrolsapplication.h"
#include "documenthandler.h"
#include <QtQml/QQmlApplicationEngine>
#include <QtGlobal>

int main(int argc, char *argv[])
{
#ifdef Q_OS_LINUX
    setenv("UBUNTU_MENUPROXY","",1);
#endif
    QtQuickControlsApplication app(argc, argv);
    qmlRegisterType<DocumentHandler>("Ide", 1, 0, "DocumentHandler");
    QQmlApplicationEngine engine(QUrl("qrc:/qml/main.qml"));
    if (engine.rootObjects().isEmpty())
        return -1;
    return app.exec();
} 
