#include "main.h"
// funzione di calcolo lunghezza stringa
int SLEN(string a)
{
    int c=0;
    for(;a[c]!=char(0);c++);
    return c;
}
// estrazione sottostringhe
string SUBSTR(string s,int left,int right)
{
    string tmp="";
    for(int c=left-1;c<right;c++)
        tmp+=s[c];
    return tmp;
}
// ricerca esistenza sottostringa
bool substr_find(string s,string c)
{
    if(s.find(c)>SLEN(s))
        return false;
    else
        return true;
}
