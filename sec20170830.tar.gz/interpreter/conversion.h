#include "basic.h"
// conversione numero intero nella stringa corrispondente
string ItoS(int n)
{
    string out="";
    for(;n>0;n/=10)
    {
        if(char(n%10+48)>47&&char(n%10+48)<58)
            out+=char(n%10+48);
        else
            out+=char(n%10+87);
    }
    int len=0;
    for(;out[len]!='\0';len++);
    for(int x=0;x<len/2;x++)
        swap(out[x],out[len-1-x]);
    return out;
}
// conversione strighe contenenti cifre ottali in numero intero
int OtoI(string octal)
{
    int out=0;
    for(int c=0;c<SLEN(octal)/2;c++)
        swap(octal[c],octal[SLEN(octal)-1-c]);
    for(int c=0;c<SLEN(octal);c++)
        out+=(int(octal[c])-48)*pow(8,c);
    return out;
}
// ricerca N� indice
string index_find(string tmp)
{
    string s="";
    int l=0,r=0;
    for(;tmp[r]!=' ';r++);
    for(int c=l;c<r;c++)
        s+=tmp[c];
    return s;
}
// ricerca istruzione
string instruction_find(string tmp)
{
    string s="";
    int l=0,r=0;
    for(;tmp[l]!=' ';l++);
        for(r=l;tmp[r]!=','&&tmp[r]!='\0';r++);
    l+=2;
    s=SUBSTR(tmp,l,r);
    return s;
}
// ricerca parametro
string parameter_find(string tmp)
{
    string s="";
    int l=0,r=SLEN(tmp);
    int cont=0;
    for(int c=0;c<SLEN(tmp);c++)
    {
        if(tmp[c]==','){
            cont++;
            l=c;
        }
    }
    l+=2;
    s=SUBSTR(tmp,l,r);
    return s;
}
// verifica indice
bool valid_index(string num)
{
    if(SLEN(num)!=4)
        return false;
    if(OtoI(num)>4095)
        return false;
    for(int c=0;c<SLEN(num);c++)
        if(!(int(num[c])>=48&&int(num[c])<=55))
            return false;
    return true;
}
// verifica istruzione
int valid_instruction(string s)
{
    if(s=="LDA"||s=="STA"||s=="ENT"||s=="ADD"||s=="SUB"||s=="AND"||s=="JMP"||s=="JZA"||s=="JPA"||s=="HLT"||s=="OR")
        return true;
    else if(s=="lda"||s=="sta"||s=="ent"||s=="add"||s=="sub"||s=="and"||s=="jmp"||s=="jza"||s=="jpa"||s=="hlt"||s=="or")
        return true;
    else
        return false;
}
// verifica parametro
bool valid_parameter(string num)
{
    if(SLEN(num)!=4)
        return false;
    if(OtoI(num)>4095)
        return false;
    for(int c=0;c<SLEN(num);c++)
        if(!(int(num[c])>=48&&int(num[c])<=55))
            return false;

    return true;
}
// converte cella di ram in numero intero
int RtoI(bool ar[])
{
    int ris=0;
    for(int c=0;c<21/2;c++)
        swap(ar[c],ar[21-1-c]);
    for(int c=0;c<20;c++)
        ris+=(ar[c]*pow(2,c));
    if(ar[20])
        ris*=-1;
    for(int c=0;c<21/2;c++)
        swap(ar[c],ar[21-1-c]);
    return ris;
}
// conversione numero intero in cella di ram
void ItoR(int val,bool ar[])
{
    int num=val;
    for(int c=20;c>0;c--,val/=2)
        ar[c]=val%2;
    if(num<0)
        ar[0]=1;
    else
        ar[0]=0;
}
// conversione numero intero in stringa ottale
string ItoO(int num)
{
    int zeri=num;
    string oct="";
    if(num==0)
        return "0000";
    for(;num>0;num/=8)
    {
        oct+=char(num%8+48);
    }
    for(int c=0;c<SLEN(oct)/2;c++)
        swap(oct[c],oct[SLEN(oct)-1-c]);
    if(zeri<8)
        return "000"+oct;
    else if(zeri<64)
        return "00"+oct;
    else if(zeri<512)
        return "0"+oct;
    else
        return oct;
}
