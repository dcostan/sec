//////////////////////////////////////////////////////////////////
// AMADIO GIANLUCA 3AT IIS ANTONIO MEUCCI CITTADELLA 27/04/2017 //
//////////////////////////////////////////////////////////////////
#include "instructions.h"
int error=2;
int main(int argc, char* argv[])
{
    string file="prog.txt";
    menu(1); ///  value 0 = sad menu  //  value 1 = fancy menu  ///*
    if(argc>1)
    {
        file=argv[1];
        ifstream presente(file.c_str());
        if(!presente){
            cout<<"File non presente !!!\n"<<endl;
            cout<<"Premere un tasto per continuare...";
            getchar();
            return 0;
        }
        presente.close();
        pp=argv[2];
        //cout<<"Premere un tasto per continuare...";
        //getchar();
    }
    else
    {
        ifstream presente;
        do
        {
            cout<<"File da aprire: ";
            cin>>file;
            presente.open(file.c_str());
        }while(!presente);
        presente.close();
        char PassoPasso;
        do
        {
            cout<<"Esecuzione passo-passo? <y/n>: ";
            cin>>PassoPasso;
        }while(PassoPasso!='y'&&PassoPasso!='n');
        if(PassoPasso=='y')
            pp=true;
    }
    string check=ifatch(file);
    if(check!="")
    {
        cout<<check;
        FINE=true;
        f.close();
    }
    if(!FINE){
        system("clear");
        cout<<"___________ISTRUZIONI__________\n"<<endl;
        cout<<"  INDX         INSTRUCTION\n"<<endl;
        for(int c=0;c<4096;c++){
                if(io[c].index!=""&&io[c].instruction!="HLT"&&io[c].instruction!="hlt")
                    cout<<"  "<<ItoO(c)<<"   <--   "<<io[c].instruction<<",0,"<<io[c].parameter<<endl;
                else if(io[c].instruction=="HLT"||io[c].instruction=="hlt")
                    cout<<"  "<<ItoO(c)<<"   <--   "<<io[c].instruction<<endl;
        }
        cout<<"_______________________________"<<endl;
        cout<<endl;
        cout<<"Premere un tasto per continuare...";
        getchar();
        system("clear");
        if(!pp){
            cout<<"___________ESECUZIONE__________\n"<<endl;
            cout<<"  INDX         INSTRUCTION\n"<<endl;
        }
        execute(pp);
        if(!pp){
            cout<<"_______________________________"<<endl;
            cout<<endl;
            cout<<"Premere un tasto per continuare...";
            getchar();
        }
        system("clear");
        cout<<"___________RISULTATI___________\n"<<endl;
        cout<<" ACC=\t";
        for(int c=0;c<21;c++)
            cout<<ACC[c];
        cout<<endl;
        for(int r=0;r<4096;r++){
            if(used[r]){
                cout<<"\n"<<ItoO(r)<<"=\t";
                for(int q=0;q<21;q++)
                    cout<<RAM[r][q];
            }
        }
        cout<<"\n\n_______________________________"<<endl;
    }
    cout<<"\n";
    cout<<" Amadio Gianluca & Costa Davide\n\n\n";
    cout<<"Premere un tasto per continuare...";
    getchar();
}
