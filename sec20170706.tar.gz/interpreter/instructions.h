#include "ifatch.h"
//////////////////////////////////////////////////////////////////////////
//                          MAIN FUNCTIONS                              //
//////////////////////////////////////////////////////////////////////////
// LDA sposta il valore di una cella nella ram nell' accumulatore
void LDA(string cell)
{
    int block=OtoI(cell);
    for(int c=0;c<21;c++)
        ACC[c]=RAM[block][c];
    cout<<"   LDA  "<<cell<<" --> ACC"<<endl;
}
// STA sposta il contenuto dell'accumulatore in una cella di ram
void STA(string cell)
{
    int block=OtoI(cell);
    for(int c=0;c<21;c++)
        RAM[block][c]=ACC[c];
    cout<<"   STA  "<<"ACC --> "<<cell<<endl;
}
// ENT posiziona nall'accumulatore un valore arbitrario
void ENT(string oct)
{
    int c=0,x=0;
    string num="000"+oct;
    for(;x<7;x++)
    {
        switch(num[x])
        {
            case('0'):
                ACC[c]=0;
                ACC[c+1]=0;
                ACC[c+2]=0;
                break;
            case('1'):
                ACC[c]=0;
                ACC[c+1]=0;
                ACC[c+2]=1;
                break;
            case('2'):
                ACC[c]=0;
                ACC[c+1]=1;
                ACC[c+2]=0;
                break;
            case('3'):
                ACC[c]=0;
                ACC[c+1]=1;
                ACC[c+2]=1;
                break;
            case('4'):
                ACC[c]=1;
                ACC[c+1]=0;
                ACC[c+2]=0;
                break;
            case('5'):
                ACC[c]=1;
                ACC[c+1]=0;
                ACC[c+2]=1;
                break;
            case('6'):
                ACC[c]=1;
                ACC[c+1]=1;
                ACC[c+2]=0;
                break;
            case('7'):
                ACC[c]=1;
                ACC[c+1]=1;
                ACC[c+2]=1;
                break;
        }
        c+=3;
    }
    cout<<"   ENT  "<<oct<<" --> ACC"<<endl;
}
// ADD somma all'accumulatore il valore contenuto in una cella di ram
void ADD(string cell)
{
    int num1=RtoI(ACC);
    int num2=RtoI(RAM[OtoI(cell)]);
    ItoR(num1+num2,ACC);
    cout<<"   ADD  "<<"ACC + "<<cell<<" "<<endl;
}
// SUB sottrae all'accumulatore il valore di una cella di ram
void SUB(string cell)
{
    int num1=RtoI(ACC);
    int num2=RtoI(RAM[OtoI(cell)]);
    ItoR(num1-num2,ACC);
    cout<<"   SUB  "<<"ACC - "<<cell<<" "<<endl;
}
// AND effettua l'operazione logica and (bit a bit) tra l'accumulatore e una cella di ram
void AND(string cell)
{
    int Ncell=OtoI(cell);
    for(int c=0;c<21;c++)
        ACC[c]=ACC[c]&&RAM[Ncell][c];
    cout<<"   AND  "<<"ACC && "<<cell<<" "<<endl;
}
// OR effettua l'operazione logica or (bit a bit) tra l'accumulatore e una cella di ram
void OR(string cell)
{
    int Ncell=OtoI(cell);
    for(int c=0;c<21;c++)
        ACC[c]=ACC[c]||RAM[Ncell][c];
    cout<<"   OR   "<<"ACC || "<<cell<<" "<<endl;
}
// JMP effettua il salto all'istruzione indicata come parametro
void JMP(string istr)
{
    ic=OtoI(istr)-1;
    cout<<"   JMP  "<<istr<<" "<<endl;
}
// JZA effettua il salto all'istruzione indicata solo se accumulatore == 0
void JZA(string istr)
{
    if(!RtoI(ACC))
        ic=OtoI(istr)-1;
    cout<<"   JZA  "<<istr<<" "<<endl;
}
// JPA effettua il salto all'istruzione indicata solo se accumulatore > 0
void JPA(string istr)
{
    if(RtoI(ACC)>0)
        ic=OtoI(istr)-1;
    cout<<"   JPA  "<<istr<<" "<<endl;
}

/// codice assolutamente inutile ( serve solo per fare un po di scena )
void Sprint(string s,int n=56)
{
    for(int c=0;c<n;c++)
    {
        for(int x=0;x<600000;x++);
        cout<<s[c];
    }
    cout<<endl;
}
void menu(bool type)
{
    string file="";
    if(type){
        cout<<endl<<endl;
        Sprint("     ad88888ba        88888888888         ,ad8888ba,   ");
        Sprint("    d8\"     \"8b       88                 d8\"'    `\"8b  ");
        Sprint("    Y8,               88                d8'            ");
        Sprint("    `Y8aaaaa,         88aaaaa           88             ");
        Sprint("      `\"\"\"\"\"8b,       88\"\"\"\"\"           88             ");
        Sprint("            `8b       88                Y8,            ");
        Sprint("    Y8a     a8P  888  88           888   Y8a.    .a8P  ");
        Sprint("     \"Y88888P\"   888  88888888888  888    `\"Y8888Y\"'   ");
        cout<<endl;
    }
}

// Il nome dice tutto no !!
void execute(bool t)
{
    for(;ic<4096&&!FINE;ic++)
    {
        if(t&&io[ic].instruction!="")
        {
            system("clear");
            cout<<"___________RISULTATI___________\n"<<endl;
            cout<<" ACC=\t";
            for(int c=0;c<21;c++)
                cout<<ACC[c];
            cout<<endl;
            for(int r=0;r<4096;r++){
                if(used[r]){
                    cout<<"\n"<<ItoO(r)<<"=\t";
                    for(int q=0;q<21;q++)
                        cout<<RAM[r][q];
                }
            }
            cout<<"\n\n_______________________________\n\nNext >>  ";
        }
        ///////////////////////////////
        //    I. DI TRASFERIMENTO    //
        ///////////////////////////////
        ///   LDA
        if(io[ic].instruction=="LDA"||io[ic].instruction=="lda")
        {
            cout<<"  "<<ItoO(ic);
            LDA(io[ic].parameter);
        }
        ///   STA
        else if(io[ic].instruction=="STA"||io[ic].instruction=="sta")
        {
            cout<<"  "<<ItoO(ic);
            STA(io[ic].parameter);
            used[OtoI(io[ic].parameter)]=true;
        }
        ///   ENT
        else if(io[ic].instruction=="ENT"||io[ic].instruction=="ent")
        {
            cout<<"  "<<ItoO(ic);
            ENT(io[ic].parameter);
        }
        ////////////////////////////////////
        //    I. DI ARITMETICO-LOGICHE    //
        ////////////////////////////////////
        ///   ADD
        else if(io[ic].instruction=="ADD"||io[ic].instruction=="add")
        {
            cout<<"  "<<ItoO(ic);
            ADD(io[ic].parameter);
        }
        ///   SUB
        else if(io[ic].instruction=="SUB"||io[ic].instruction=="sub")
        {
            cout<<"  "<<ItoO(ic);
            SUB(io[ic].parameter);
        }
        ///   AND
        else if(io[ic].instruction=="AND"||io[ic].instruction=="and")
        {
            cout<<"  "<<ItoO(ic);
            AND(io[ic].parameter);
        }
        ///   OR
        else if(io[ic].instruction=="OR"||io[ic].instruction=="or")
        {
            cout<<"  "<<ItoO(ic);
            OR(io[ic].parameter);
        }
        ///////////////////////////
        //    I. DI CONTROLLO    //
        ///////////////////////////
        ///   HLT
        else if(io[ic].instruction=="HLT")
        {
            cout<<"  "<<ItoO(ic)<<"   HLT  (Fine)"<<endl;
            FINE=true;
        }
        ///   JMP
        else if(io[ic].instruction=="JMP"||io[ic].instruction=="jmp")
        {
            cout<<"  "<<ItoO(ic);
            JMP(io[ic].parameter);
        }
        ///   JZA
        else if(io[ic].instruction=="JZA"||io[ic].instruction=="jza")
        {
            cout<<"  "<<ItoO(ic);
            JZA(io[ic].parameter);
        }
        ///   JPA
        else if(io[ic].instruction=="JPA"||io[ic].instruction=="jpa")
        {
            cout<<"  "<<ItoO(ic);
            JPA(io[ic].parameter);
        }
        if(pp&&io[ic].instruction!=""){
            cout<<"Premere un tasto per continuare...";
            getchar();
        }
    }
}
