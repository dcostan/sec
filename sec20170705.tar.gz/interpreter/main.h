#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <math.h>
using namespace std;
struct LINE{
    string index;
    string instruction;
    string parameter;
};
fstream f;
LINE io[4096];
unsigned int ic=0;
bool RAM[4096][21];
bool used[4096];
bool ACC[21],FINE=false;
bool pp=false;
