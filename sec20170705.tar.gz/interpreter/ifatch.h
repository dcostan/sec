#include "conversion.h"
string ifatch(string file)
{
    int line=0;
    string instruction="";
    string parameter="";
    string index_number="";
    string tmp="";
    f.open(file);
    while(!f.eof())
    {
        getline(f,tmp);
        if(tmp[0]=='#')
            break;
        line++;
        index_number = index_find(tmp);
        if(tmp!="")
        {
            instruction   = instruction_find(tmp);
            if(instruction=="HLT"||instruction=="hlt")
                parameter="0000";
            else
                parameter=parameter_find(tmp);
            if(valid_index(index_number))
            {
                if(valid_instruction(instruction))
                {
                    if(valid_parameter(parameter))
                    {
                        io[OtoI(index_number)].index=index_number;
                        io[OtoI(index_number)].instruction=instruction;
                        io[OtoI(index_number)].parameter=parameter;
                    }
                    else
                        return "Error <invalid parameter> at line <"+ItoS(line)+">";
                }
                else
                    return "Error <invalid instruction> at line <"+ItoS(line)+">";
            }
            else
                return "Error <invalid instruction-index> at line <"+ItoS(line)+">";
        }
    }
    f.close();
    return "";
}
